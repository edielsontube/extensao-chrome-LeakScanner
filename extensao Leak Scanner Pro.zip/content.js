(() => {
    // Verificar se o scanner já está em execução
    if (document.getElementById('leakScannerModal')) {
        console.log("Leak Scanner já está em execução.");
        return;
    }

    const style = `
    #leakScannerModal {
      position: fixed; top: 10%; left: 50%; transform: translateX(-50%);
      background: #0d1117; color: #c9d1d9; font-family: monospace;
      padding: 20px; border: 2px solid #58a6ff; border-radius: 12px;
      max-width: 80%; z-index: 999999; box-shadow: 0 0 20px #58a6ff;
    }
    #leakScannerModal h2 {margin-top: 0; color: #58a6ff;}
    #leakScannerModal pre {white-space: pre-wrap; word-wrap: break-word; max-height: 400px; overflow-y: auto;}
    #leakScannerModal button {background: #58a6ff; color: #0d1117; padding: 5px 10px; border: none; border-radius: 8px; cursor: pointer;}
    #report {
      margin-top: 20px;
      background: #161b22;
      padding: 10px;
      border-radius: 8px;
      color: #c9d1d9;
    }
    #report h3 {color: #58a6ff;}
    #report ul {list-style: none; padding: 0;}
    #report ul li {margin: 5px 0;}
    `;

    const modal = document.createElement("div");
    modal.id = "leakScannerModal";
    modal.innerHTML = `
      <h2>🔍 Leak Scanner Pro</h2>
      <pre>⏳ Escaneando...</pre>
      <button onclick="this.parentElement.remove()">Fechar</button>
    `;
    document.body.appendChild(modal);

    const styleTag = document.createElement("style");
    styleTag.textContent = style;
    document.head.appendChild(styleTag);

    const patterns = [
      { label: "🔑 Google API Key", regex: /AIza[0-9A-Za-z-_]{35}/g },
      { label: "🔐 Stripe Live Key", regex: /sk_live_[0-9a-zA-Z]{24}/g },
      { label: "🛡️ Google OAuth", regex: /ya29\.[0-9A-Za-z\-_]+/g },
      { label: "📦 AWS Access Key", regex: /A[SK]IA[0-9A-Z]{16}/g },
      { label: "🔑 Facebook Token", regex: /EAACEdEose0cBA[0-9A-Za-z]+/g },
      { label: "🔑 Mailgun Key", regex: /key-[0-9a-zA-Z]{32}/g },
      { label: "📞 Twilio SID", regex: /AC[a-zA-Z0-9_\-]{32}/g },
      { label: "🔓 JWT", regex: /ey[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.[A-Za-z0-9-_.+/=]*/g },
      { label: "🔑 Bearer Token", regex: /Bearer\s+[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/g },
      { label: "🔐 RSA Private Key", regex: /-----BEGIN RSA PRIVATE KEY-----/g },
      { label: "🔐 PGP Key", regex: /-----BEGIN PGP PRIVATE KEY BLOCK-----/g },
      { label: "🔍 Email", regex: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-zA-Z]{2,7}/g },
      { label: "🔑 Generic Secret", regex: /(?:password|passwd|pwd|token|secret)[=:]\s*['"]?([a-zA-Z0-9_-]{4,})['"]?/gi },
      { label: "🧪 API Key", regex: /(?:api[_-]?key|access[_-]?token|secret)[=:]\s*['"]?([a-zA-Z0-9_-]{20,})['"]?/gi },
      { label: "🔑 GitHub Token", regex: /ghp_[A-Za-z0-9_]{36}/g },
      { label: "🔑 Slack Token", regex: /xox[baprs]-[0-9]{12}-[0-9]{12}-[a-zA-Z0-9]{24}/g },
      { label: "🔑 Heroku Key", regex: /[a-zA-Z0-9]{8}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{12}/g },
      { label: "📂 Exposed Directory", regex: /\/(admin|backup|config|db|private|test|staging|debug)/gi },
    ];

    const sensitiveEndpoints = [
      { label: "🔒 API Endpoint", regex: /\/api\/v[0-9]+/g },
      { label: "💾 GraphQL", regex: /\/graphql/g },
      { label: "🔑 Auth Endpoint", regex: /\/(auth|login|signin|signup|register)/g },
      { label: "💰 Payment", regex: /\/(payment|checkout|billing)/g },
      { label: "👤 User Data", regex: /\/(user|profile|account)/g },
      { label: "⚙️ Admin", regex: /\/(admin|dashboard|manage|control)/g }
    ];

    const sources = [
      document.body?.innerText || "",
      document.head?.innerHTML || "",
      Array.from(document.querySelectorAll("script")).map(s => s.innerText).join("\n"),
      JSON.stringify(localStorage),
      JSON.stringify(sessionStorage),
      Array.from(document.querySelectorAll('a')).map(a => a.href).join('\n'),
      Array.from(document.querySelectorAll('form')).map(f => f.action).join('\n')
    ].join("\n\n");

    let found = [];
    patterns.concat(sensitiveEndpoints).forEach(({label, regex}) => {
      const matches = sources.match(regex);
      if (matches) {
        matches.forEach(m => found.push(`${label}: ${m}`));
      }
    });

    const runAllChecks = async () => {
      const checkSecurityHeaders = async () => {
        try {
          const response = await fetch(window.location.href, { method: 'HEAD' });
          const headers = response.headers;
          const securityHeaders = [
            { name: "X-Frame-Options", recommended: "DENY" },
            { name: "X-XSS-Protection", recommended: "1; mode=block" },
            { name: "Content-Security-Policy", required: true },
            { name: "Strict-Transport-Security", required: true },
            { name: "X-Content-Type-Options", recommended: "nosniff" }
          ];

          securityHeaders.forEach(header => {
            if (!headers.get(header.name)) {
              found.push(`⚠️ Missing Security Header: ${header.name}`);
            }
          });
        } catch (err) {
          console.error("Erro ao verificar headers de segurança:", err);
        }
      };

      const checkJsVulnerabilities = () => {
        const jsVulnerabilityPatterns = [
          { label: "🔴 Eval Usage", regex: /eval\((.*?)\)/g },
          { label: "⚠️ innerHTML", regex: /\.innerHTML\s*=/g },
          { label: "⚠️ document.write", regex: /document\.write\(/g },
          { label: "🔓 Insecure SSL", regex: /rejectUnauthorized:\s*false/g },
          { label: "🔓 Weak Crypto", regex: /crypto\.createHash\('md5'\)/g }
        ];

        const scripts = Array.from(document.querySelectorAll('script'));
        scripts.forEach(script => {
          jsVulnerabilityPatterns.forEach(({label, regex}) => {
            if (regex.test(script.textContent)) {
              found.push(`${label}: Potential vulnerability in script`);
            }
          });
        });
      };

      const checkCookiesSecurity = () => {
        document.cookie.split(';').forEach(cookie => {
          if (!cookie.includes('Secure')) {
            found.push(`🍪 Insecure Cookie: ${cookie.trim()}`);
          }
          if (!cookie.includes('HttpOnly')) {
            found.push(`🍪 Cookie without HttpOnly: ${cookie.trim()}`);
          }
          if (!cookie.includes('SameSite')) {
            found.push(`🍪 Cookie without SameSite: ${cookie.trim()}`);
          }
        });
      };

      const checkForms = () => {
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
          if (!form.querySelector('input[type="hidden"][name*="csrf"]')) {
            found.push(`🔓 Form without CSRF Token: ${form.action}`);
          }
          
          const inputs = form.querySelectorAll('input');
          inputs.forEach(input => {
            if (!input.getAttribute('autocomplete')) {
              found.push(`⚠️ Input without autocomplete: ${input.name}`);
            }
          });
        });
      };

      const checkOutdatedTech = () => {
        const outdatedTechPatterns = [
          { name: "jQuery", pattern: /jquery-([0-9.]+)\.min\.js/, maxVersion: "3.6.0" },
          { name: "Bootstrap", pattern: /bootstrap-([0-9.]+)\.min\.js/, maxVersion: "5.1.0" },
          { name: "Angular", pattern: /angular\.version\.full\s*=\s*["']([0-9.]+)/, maxVersion: "13.0.0" },
          { name: "React", pattern: /react@([0-9.]+)/, maxVersion: "17.0.0" }
        ];

        const scripts = document.querySelectorAll('script[src]');
        scripts.forEach(script => {
          outdatedTechPatterns.forEach(({name, pattern, maxVersion}) => {
            const match = script.src.match(pattern);
            if (match && match[1] < maxVersion) {
              found.push(`⚠️ Outdated ${name} version: ${match[1]}`);
            }
          });
        });
      };

      const checkComments = () => {
        const comments = document.evaluate(
          '//comment()',
          document,
          null,
          XPathResult.ANY_TYPE,
          null
        );
        
        let comment;
        while (comment = comments.iterateNext()) {
          if (/todo|fixme|hack|xxx|bug|debug/i.test(comment.textContent)) {
            found.push(`💭 Sensitive Comment Found: ${comment.textContent.trim()}`);
          }
        }
      };

      const checkRedirects = () => {
        const links = document.querySelectorAll('a[href*="redirect"], a[href*="return"], a[href*="next"]');
        links.forEach(link => {
          if (link.href.includes('http') && !link.href.startsWith(window.location.origin)) {
            found.push(`🔄 Potentially Unsafe Redirect: ${link.href}`);
          }
        });
      };

      await checkSecurityHeaders();
      checkJsVulnerabilities();
      checkCookiesSecurity();
      checkForms();
      checkOutdatedTech();
      checkComments();
      checkRedirects();
    };

    runAllChecks().then(() => {
      const output = found.length ? [...new Set(found)].join("\n") : "✅ Nenhum vazamento encontrado.";
      modal.querySelector("pre").textContent = output;

      // Adicionar relatório visual
      modal.innerHTML += `
        <div id="report">
          <h3>Resumo de Vulnerabilidades</h3>
          <ul>
            ${patterns.concat(sensitiveEndpoints).map(p => 
              `<li>${p.label || p.type}: ${found.filter(f => f.startsWith(p.label || p.type)).length}</li>`
            ).join("")}
          </ul>
        </div>`;
    });

    console.log("🕵️‍♂️ Leak Scanner Pro Resultado:", found);
})();
